Hey :)

These tests are based on the existing tests sent here before. Credit due.
We fixed test 11 and added some more tests of our own. 

We highly recommend you to do the new tests as well, due to 2 differences between our exercise and last year's exercise.

Differrences :

A. All of past tests , test 11 included, summed up all of the children and not just the leaves.
B. In a case of two proccess with the same weight it didn't returned the youngest one (get_heaviest_ancestor).

Previous Tests did not cover case

Feel free to ask questions or correct us.

Let's go MESSI!


Actions:

1. type make
2. run ./test_weight.exe