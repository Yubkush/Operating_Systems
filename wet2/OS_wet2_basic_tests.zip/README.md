Replace the "files" directory given by the course staff with the directory in the zip.<br />
From within the "files" directory run <br />
```
chmod +x run_tests.sh
./run_tests.sh
```
